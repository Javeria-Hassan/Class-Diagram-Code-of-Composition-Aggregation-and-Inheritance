﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicle_Code
{
    class Engine
    {
        protected int EngineID;
        public Engine(int Id)
        {
            this.EngineID = Id;
        }
    }
}
