﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicle_Code
{
    class othervehicle:Vehicle
    {
        private int id;
        public othervehicle(Engine eng, AC ac, int id) : base(eng,id)
        {

            this.id = id;
        }
        public override void display()
        {
            Console.WriteLine("the number of engine in car :" + engineID);
            Console.WriteLine("the number of ac in car: " + acID);
        }
    }
}
